import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-to-issue',
  templateUrl: './member-to-issue.component.html',
  styleUrls: ['./member-to-issue.component.css']
})
export class MemberToIssueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
